<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Pays</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: #a7ffeb;
            font-family: 'Comic Sans MS', cursive, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #ffab91;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            margin: 10px;
            font-size: 1em;
            box-shadow: 2px 2px 4px #888888;
        }
        .back-button:hover {
            background-color: #ffcc80;
        }
        h1 {
            color: #2979ff;
            margin-top: 20px;
        }
        .country-info {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 5px 5px 10px #888888;
            margin: 20px auto;
            max-width: 600px;
        }
        .country-info img {
            display: block;
            margin: 10px auto;
            width: 150px;
            height: auto;
            border: 2px solid #ccc;
            border-radius: 5px;
        }
        .country-info p {
            font-size: 1.1em;
            line-height: 1.6;
        }
        .arabic-text {
            font-size: 1.3em;
            color: #d50000;
        }
        audio {
            display: block;
            margin: 10px auto;
        }
    </style>
</head>
<body>
    <a href="continent.php?continent=<?php echo $_GET['continent']; ?>" class="back-button">← Revenir</a>
    <?php
    $pays = $_GET['pays'];
    $continent = $_GET['continent'];
    $info = array();

    if ($pays == "Canada") {
        $info = array(
            "capitale" => "Ottawa",
            "bonjour" => "Hello",
            "audio" => "hello.mp3"
        );
    } elseif ($pays == "Etats-Unis") {
        $info = array(
            "capitale" => "Washington D.C.",
            "bonjour" => "Hello",
            "audio" => "hello.mp3"
        );
    } elseif ($pays == "Mexique") {
        $info = array(
            "capitale" => "Mexico",
            "bonjour" => "Hola",
            "audio" => "hola.mp3"
        );
    } elseif ($pays == "Bresil") {
        $info = array(
            "capitale" => "Brasilia",
            "bonjour" => "Olá", // Tu n'as pas "olá.mp3", j'utilise une approximation
            "audio" => "hola.mp3"
        );
    } elseif ($pays == "Argentine") {
        $info = array(
            "capitale" => "Buenos Aires",
            "bonjour" => "Hola",
            "audio" => "hola.mp3"
        );
    } elseif ($pays == "Colombie") {
        $info = array(
            "capitale" => "Bogota",
            "bonjour" => "Hola",
            "audio" => "hola.mp3"
        );
    } elseif ($pays == "Maroc") {
        $info = array(
            "capitale" => "Rabat",
            "bonjour" => "السلام عليكم <span class='arabic-text'>(As-salamu alaykum)</span>",
            "audio" => "salam.mp3"
        );
    } elseif ($pays == "Egypte") {
        $info = array(
            "capitale" => "Le Caire",
            "bonjour" => "أهلاً وسهلاً <span class='arabic-text'>(Ahlan wa sahlan)</span>",
            "audio" => "salam.mp3" // Approximation, tu n'as pas un fichier spécifique
        );
    } elseif ($pays == "Nigeria") {
        $info = array(
            "capitale" => "Abuja",
            "bonjour" => "Hello",
            "audio" => "hello.mp3"
        );
    } elseif ($pays == "France") {
        $info = array(
            "capitale" => "Paris",
            "bonjour" => "Bonjour",
            "audio" => "bonjour.mp3"
        );
    } elseif ($pays == "Allemagne") {
        $info = array(
            "capitale" => "Berlin",
            "bonjour" => "Hallo",
            "audio" => "hallo.mp3"
        );
    } elseif ($pays == "Italie") {
        $info = array(
            "capitale" => "Rome",
            "bonjour" => "Ciao",
            "audio" => "ciao.mp3"
        );
    } elseif ($pays == "Japon") {
        $info = array(
            "capitale" => "Tokyo",
            "bonjour" => "こんにちは <span class='arabic-text'>(Konnichiwa)</span>",
            "audio" => "konnichiwa.mp3"
        );
    } elseif ($pays == "Chine") {
        $info = array(
            "capitale" => "Pékin",
            "bonjour" => "你好 <span class='arabic-text'>(Nǐ hǎo)</span>",
            "audio" => "ni hao.mp3"
        );
    } elseif ($pays == "Inde") {
        $info = array(
            "capitale" => "New Delhi",
            "bonjour" => "नमस्ते <span class='arabic-text'>(Namaste)</span>",
            "audio" => "namaste.mp3"
        );
    } elseif ($pays == "Australie") {
        $info = array(
            "capitale" => "Canberra",
            "bonjour" => "Hello", // Approximation, tu n'as pas "g'day.mp3"
            "audio" => "hello.mp3"
        );
    } elseif ($pays == "Nouvelle-Zelande") {
        $info = array(
            "capitale" => "Wellington",
            "bonjour" => "Halo", // Approximation, tu n'as pas "kia ora.mp3"
            "audio" => "halo.mp3"
        );
    } elseif ($pays == "Fidji") {
        $info = array(
            "capitale" => "Suva",
            "bonjour" => "Halo", // Approximation, tu n'as pas "bula.mp3"
            "audio" => "halo.mp3"
        );
    } elseif ($pays == "Vanuatu") {
        $info = array(
            "capitale" => "Port Vila",
            "bonjour" => "Halo",
            "audio" => "halo.mp3"
        );
    }
    ?>

    <div class="country-info">
        <h1><?php echo $pays; ?></h1>

        <?php if (!empty($info['drapeau'])) { ?>
            <img src="images/<?php echo $info['drapeau']; ?>" alt="Drapeau de <?php echo $pays; ?>">
        <?php } ?>

        <?php if (!empty($info['capitale'])) { ?>
            <p><strong>Capitale :</strong> <?php echo $info['capitale']; ?></p>
        <?php } ?>

        <?php if (!empty($info['bonjour'])) { ?>
            <p><strong>Bonjour :</strong> <?php echo $info['bonjour']; ?></p>
        <?php } ?>

        <?php if (!empty($info['audio'])) { ?>
            <audio controls>
                <source src="sons/<?php echo $info['audio']; ?>" type="audio/mpeg">
                Votre navigateur ne supporte pas l'élément audio.
            </audio>
        <?php } ?>
    </div>
</body>
</html>

   